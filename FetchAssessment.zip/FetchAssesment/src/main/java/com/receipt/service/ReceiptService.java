package com.receipt.service;

import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class ReceiptService {

    private final Map<String, Receipt> receiptStorage = new HashMap<>();
    public String processReceipt(Receipt receipt) {
        String id = UUID.randomUUID().toString();
        receiptStorage.put(id, receipt);
        return id;
    }

    public int getPoints(String id) {
        Receipt receipt = receiptStorage.get(id);
        if (receipt == null) {
            throw new IllegalArgumentException("Receipt not found for ID: " + id);
        }
        return calculatePoints(receipt);
    }

    private int calculatePoints(Receipt receipt) {
        int points = 0;

        points += receipt.getRetailer().replaceAll("[^a-zA-Z0-9]", "").length();
        if (receipt.getTotal().matches("\\d+\\.00")) {
            points += 50;
        }
        double total = Double.parseDouble(receipt.getTotal());
        if (total % 0.25 == 0) {
            points += 25;
        }
        points += (receipt.getItems().size() / 2) * 5;
        for (Receipt.Item item : receipt.getItems()) {
            if (item.getShortDescription().trim().length() % 3 == 0) {
                points += Math.ceil(Double.parseDouble(item.getPrice()) * 0.2);
            }
        }
        int day = Integer.parseInt(receipt.getPurchaseDate().split("-")[2]);
        if (day % 2 != 0) {
            points += 6;
        }
        String[] timeParts = receipt.getPurchaseTime().split(":");
        int hour = Integer.parseInt(timeParts[0]);
        int minute = Integer.parseInt(timeParts[1]);
        if (hour == 14 || (hour == 15 && minute == 0)) {
            points += 10;
        }

        return points;
    }
}
